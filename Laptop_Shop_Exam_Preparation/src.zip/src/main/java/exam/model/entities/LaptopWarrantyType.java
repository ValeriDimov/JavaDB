package exam.model.entities;

public enum LaptopWarrantyType {
    BASIC, PREMIUM, LIFETIME
}
