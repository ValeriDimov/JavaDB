package exam.model.dtos;

public class ImportTownCustomerDTO {
    private String name;

    public ImportTownCustomerDTO() {
    }

    public String getName() {
        return name;
    }
}
