package exam.model.dtos;

public class ImportShopCustomerDTO {
    private String name;

    public ImportShopCustomerDTO() {
    }

    public String getName() {
        return name;
    }
}
