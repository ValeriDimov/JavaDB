package com.example.spring_data_intro_exercise.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
